# SQLBot Application Package

This package contains the SQLBot application with built-in PostgreSQL database.

## Contents
- sqlbot-app.yaml: Kubernetes deployment configuration
- Applicationfile: Sealos application definition

## Usage
To deploy this application to an existing Kubernetes cluster:

```bash
kubectl apply -f sqlbot-app.yaml
```

## Requirements
- Kubernetes cluster (1.25+)
- At least 4GB RAM available
- At least 2 CPU cores available
- Persistent volume support for data storage
